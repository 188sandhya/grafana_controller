+++
title = "Copyright notice"
aliases = ["/docs/grafana/next/copyright-notice"]
+++

# Copyright notice

Copyright &#169; 2021 Raintank, Inc. dba Grafana Labs. All Rights Reserved
