+++
title = "View server"
weight = 100
+++

# View server information

This setting contains information about tools that Grafana Server Admins can use to learn more about their Grafana servers.
